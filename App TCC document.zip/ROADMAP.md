# ROADMAP — Mentis

**v1.0 — fases de entrega.** Desenvolvimento iterativo e rápido (PRD §1): cada fase entrega
valor real e instrumenta aprendizado.

---

## Fase 0 — Fundação (1 sprint)
- Monorepo, CI, TypeScript estrito, tokens do `DESIGNSYSTEM.md` em `theme/tokens.ts`.
- Esqueleto de navegação (5 abas + Exercícios) e componentes-base (Button, Card, eyebrow, chips).
- Auth básica + modelo `User` + onboarding mínimo (nome, objetivos, baseline de humor).
- **Pronto quando:** app abre, navega entre telas vazias, usuário cria conta.

## Fase 1 — MVP (núcleo de valor)
Objetivo: o loop completo "agir → ver crescer".
- **F1 Diário guiado** (4 etapas) + persistência.
- **F2 Exercícios** — catálogo inicial (`thought_record`, `cognitive_restructuring`,
  `action_planning`) com fluxo guiado.
- **F3 Metas** — hábitos do dia (checklist) + 1 objetivo com subtarefas.
- **F6 Cidade** — cena com edifícios, próximo marco, créditos de tijolos por ação
  (regras do `SPEC §3`, calculadas no backend).
- **Check-in de humor** no Início + sequência (streak).
- **IA mínima:** `analyze-journal` (detecção de distorção) com guardrails de segurança.
- **Pronto quando:** usuário registra um pensamento, recebe análise da IA, conclui um
  exercício/hábito e **vê tijolos somarem na cidade**.

## Fase 2 — Inteligência e retenção
- **F4 Lembretes inteligentes** (horário/rotina/padrões; respeita quiet hours).
- **F5 Análise de progresso** completa (humor, consistência, frequência, tendências por IA).
- **IA adaptativa:** personalização de exercícios e metas (`personalize-exercises`, `trends`).
- Exercícios restantes: `core_beliefs`, `behavioral_hypothesis`.
- Gamificação: níveis da vila, desbloqueio de áreas, novos tipos de edifício.
- **Pronto quando:** o app prioriza conteúdo por histórico e devolve insights úteis.

## Fase 3 — Polimento e escala
- Offline-first robusto + sync; exportação/exclusão de dados (LGPD).
- Acessibilidade AA completa; fontes ampliadas; leitores de tela.
- iOS em paridade; performance; analytics do `PRD §9` instrumentado.
- **Pronto quando:** pronto para lojas, métricas-norte sendo medidas.

## Longo prazo (PRD §11)
Versões temáticas (produtividade/ansiedade/disciplina); versões culturais/religiosas
(ex.: abordagem cristã); integração com terapeutas; comunidade; programas estruturados.

---

## Definition of Done (transversal)
- [ ] Segue `DESIGNSYSTEM.md` (tokens, componentes, tom calmo).
- [ ] Respeita contratos de dados do `SPEC §2` e regras de gamificação do `SPEC §3`.
- [ ] IA dentro dos limites do `SPEC §7` (guia, não terapeuta; guardrails de risco).
- [ ] Acessível (alvos ≥44px, contraste AA, cor nunca sozinha).
- [ ] Funciona offline onde especificado; degrada com elegância sem IA.
- [ ] Testes nas regras de gamificação e guardrails; typecheck e lint limpos.
- [ ] Sem dark patterns; sem punição por inatividade.
