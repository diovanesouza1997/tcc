# PRD — Mentis

**Documento de Requisitos de Produto · v1.0**

---

## 1. Visão geral

Mentis é um SaaS/app de assistência pessoal baseado em **Terapia Cognitivo-Comportamental
(TCC)**, com foco em desenvolvimento pessoal prático, progressivo e orientado por IA.

A plataforma funciona como um **assistente digital de crescimento pessoal**: ajuda o usuário a
compreender seus padrões mentais, regular emoções e transformar comportamentos no cotidiano.
Inspirado na metodologia da TCC, guia o usuário em um processo estruturado de
autodesenvolvimento — semelhante ao acompanhamento de sessões terapêuticas, porém adaptado
para uso autônomo e contínuo.

Construído para **desenvolvimento iterativo e rápido**, evoluindo com base no comportamento dos
usuários e em recomendações geradas por IA.

## 2. Problema

Conceitos terapêuticos (distorções cognitivas, reestruturação, crenças centrais) são
poderosos mas **abstratos**. As pessoas:
- não conseguem aplicá-los sozinhas no dia a dia;
- abandonam apps de hábitos/journaling por falta de retorno visível;
- não percebem que pequenas ações produzem resultado acumulado.

## 3. Proposta de valor

O sistema ajuda o usuário a:
- Identificar padrões de pensamento disfuncionais;
- Registrar emoções e situações do cotidiano;
- Reestruturar pensamentos negativos ou distorcidos;
- Desenvolver hábitos consistentes;
- Planejar ações práticas;
- Monitorar progresso comportamental.

A experiência é **personalizada e adaptativa** — a IA ajusta exercícios, sugestões e metas
conforme o uso. O objetivo central é **transformar conceitos terapêuticos abstratos em ações
práticas e mensuráveis**.

## 4. Diferencial central — Gamificação visual do crescimento

O principal diferencial é um sistema de gamificação baseado na **metáfora de construção**.
Cada ação positiva (completar um exercício, cumprir um hábito, registrar um pensamento)
contribui para a construção de um ambiente virtual:

- Cada tarefa concluída adiciona **tijolos** a construções;
- Hábitos consistentes constroem **edifícios maiores**;
- Sequências de disciplina **desbloqueiam novas áreas**;
- Com o tempo, o usuário vê uma **cidade crescer** — começando por um único edifício.

> O crescimento pessoal torna-se visível, concreto e acumulativo, aumentando motivação e
> engajamento. Pequenas ações produzem resultados cumulativos que se pode **ver**.

## 5. Fundamento teórico

Fundamentado **principalmente em TCC**, priorizando métodos empiricamente validados e
estruturados. Pode incorporar, de forma complementar: neurociência comportamental, princípios
de mudança de hábitos, psicologia baseada em propósito (ex.: logoterapia) e insights
motivacionais. Base **prática e orientada a resultados**, evitando abordagens excessivamente
teóricas ou especulativas.

Inicialmente **100% focado em TCC**, com possibilidade futura de versões temáticas/culturais
(ex.: abordagem alinhada a valores cristãos).

## 6. Público-alvo inicial

- Pessoas interessadas em desenvolvimento pessoal estruturado;
- Usuários com ansiedade leve a moderada;
- Pessoas que desejam melhorar disciplina e hábitos;
- Usuários interessados em autoconhecimento prático.

**Não é**, inicialmente, substituto de psicoterapia clínica — é ferramenta **complementar**.

## 7. Funcionalidades principais (escopo)

| # | Funcionalidade | Descrição |
|---|---|---|
| F1 | **Diário guiado inteligente** | Registro de situações, pensamentos e emoções com prompts estruturados; IA identifica distorções e padrões e sugere novas interpretações. |
| F2 | **Exercícios de reestruturação cognitiva** | Exercícios clássicos de TCC adaptados ao histórico: registro de pensamentos automáticos, identificação de crenças centrais, reestruturação, teste de hipóteses, planejamento de ações. |
| F3 | **Metas e planejamento comportamental** | Definição de hábitos, objetivos e ações; objetivos abstratos viram tarefas pequenas e executáveis. |
| F4 | **Lembretes inteligentes** | Lembretes baseados em horário, rotina, comportamento anterior e padrões detectados, para aumentar aderência. |
| F5 | **Análise de progresso** | Evolução emocional, consistência de hábitos, frequência de exercícios e tendências comportamentais. |
| F6 | **Gamificação visual (a Cidade)** | Diferencial central — ver seção 4. |

## 8. Papel da Inteligência Artificial

A IA é responsável por: personalizar exercícios, adaptar metas, sugerir intervenções,
identificar padrões e ajustar o nível de desafio. **A plataforma evolui com o usuário.**

**Limites rígidos da IA** (ver `SPEC.md §7`):
- Atua como **guia estruturado**, nunca como terapeuta;
- Não diagnostica nem dá conselhos clínicos;
- Encaminha a ajuda profissional/emergência diante de sinais de risco.

## 9. Métricas de sucesso

- **Aderência:** % de usuários ativos D7 / D30; tamanho médio de sequência (streak).
- **Profundidade:** exercícios concluídos / usuário / semana; registros de diário / semana.
- **Resultado percebido:** tendência da auto-avaliação de humor ao longo do tempo.
- **Engajamento da gamificação:** % que visita a Cidade ≥ 3x/semana; edifícios construídos.
- **Retenção:** retenção D30 como métrica-norte.

## 10. Fora de escopo (v1)

- Diagnóstico clínico ou substituição de terapia.
- Integração com terapeutas humanos / teleconsulta.
- Comunidade entre usuários.
- Versões temáticas/culturais (planejadas para longo prazo).

## 11. Visão de longo prazo

Versões temáticas (produtividade, ansiedade, disciplina); versões culturais/religiosas;
integração com terapeutas; comunidade entre usuários; programas estruturados de crescimento.
