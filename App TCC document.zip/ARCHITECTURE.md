# ARCHITECTURE — Mentis

**v1.0 — referência de stack e estrutura.** É uma recomendação pragmática para um app
mobile-first com IA; ajuste conforme as preferências do time, mantendo os contratos do `SPEC.md`.

---

## 1. Stack recomendada

| Camada | Escolha | Por quê |
|---|---|---|
| App mobile | **React Native + Expo** (TypeScript) | Android-first com caminho fácil para iOS; OTA updates; itera rápido |
| Estado | **Zustand** (ou Redux Toolkit) | leve, simples para estado de UI + cache local |
| Navegação | **expo-router** / React Navigation | rotas declarativas alinhadas ao mapa do `SPEC §1` |
| Estilo | tokens de `DESIGNSYSTEM.md` em um `theme.ts` | inline/objeto de estilo; sem CSS global |
| Backend | **Node.js + Fastify** (ou NestJS) | API typed, performática |
| Banco | **PostgreSQL** + Prisma | relacional encaixa nos modelos do `SPEC §2` |
| Auth | e-mail/senha + OAuth (Apple/Google) | exigência de loja |
| IA | **Claude (Anthropic API)** via backend | nunca chamar a IA direto do cliente |
| Notificações | Expo Notifications / FCM | lembretes inteligentes (F4) |
| Analytics | PostHog (self-host opcional) | métricas do `PRD §9`, privacy-friendly |

> Alternativa "rápida para validar": Expo + **Supabase** (Postgres + Auth + storage gerenciados)
> e uma única Edge/Cloud Function para o proxy de IA.

## 2. Estrutura de pastas (monorepo sugerido)

```
mentis/
├── apps/
│   └── mobile/                 # Expo app
│       ├── app/                # rotas (expo-router): index, diario, exercicios, metas, progresso, cidade
│       ├── src/
│       │   ├── components/     # UI do DESIGNSYSTEM (Button, Card, MoodPicker, HabitRow, CityScene…)
│       │   ├── features/       # diario, exercicios, metas, progresso, cidade, onboarding
│       │   ├── theme/          # tokens.ts (cores/tipo/espaço), extraídos do DESIGNSYSTEM.md
│       │   ├── store/          # zustand stores
│       │   ├── api/            # client tipado do backend
│       │   └── lib/            # gamificação (regras de tijolos), datas, validação
│       └── assets/fonts/       # Newsreader, Plus Jakarta Sans
├── services/
│   └── api/                    # Fastify + Prisma
│       ├── src/modules/        # users, mood, journal, exercises, habits, goals, progress, city, ai
│       ├── src/ai/             # prompts, schemas de saída, guardrails de segurança
│       └── prisma/schema.prisma
├── packages/
│   └── shared/                 # tipos compartilhados (espelham SPEC §2), constantes da gamificação
└── docs/                       # PRD, SPEC, DESIGNSYSTEM, ROADMAP (estes arquivos)
```

## 3. Camada de IA (crítico)

- **Sempre via backend.** O cliente nunca conhece a chave da API.
- Cada uso de IA é um endpoint com **schema de entrada e saída validado** (zod). A IA retorna
  JSON estruturado, não texto solto. Ex.:
  - `POST /ai/analyze-journal` → `{ distortion, confidence, explanation, reframePrompt }`
  - `POST /ai/personalize-exercises` → `{ ordered: ExerciseId[], rationale }`
  - `POST /ai/trends` → `{ insights: { text, suggestedExerciseType }[] }`
- **Guardrails de segurança** antes de devolver ao cliente: detecção de sinais de risco →
  resposta de acolhimento + recursos de emergência (CVV 188), sem tentar "tratar".
  Ver `SPEC §7`.
- **Minimização de dados:** enviar à IA só o necessário; respeitar modo de retenção reduzida.
- Degradação graciosa: se a IA falhar/timeout, a feature funciona sem a sugestão.

## 4. Dados e sincronização

- **Offline-first** para check-ins, registros e marcação de hábitos (fila local → sync).
- Gamificação calculada no **backend** (fonte da verdade dos tijolos) com atualização otimista
  no cliente; a config de valores (`SPEC §3`) vem de tabela/feature flags para tuning sem deploy.
- Migrações versionadas (Prisma migrate).

## 5. Segurança e conformidade
- TLS em trânsito; criptografia em repouso para dados sensíveis.
- **LGPD:** consentimento explícito, exportação e exclusão de dados pelo usuário (endpoints dedicados).
- PII e conteúdo de diário tratados como **dados sensíveis de saúde**.
- Logs sem conteúdo de diário em texto claro.

## 6. Qualidade
- **TypeScript estrito** em todo o monorepo; tipos compartilhados em `packages/shared`.
- Testes: unitários nas regras de gamificação e nos guardrails de IA; e2e dos fluxos críticos
  (diário → análise, marcar hábito → tijolo, concluir exercício).
- Lint/format: ESLint + Prettier. CI rodando lint + testes + typecheck.

## 7. Ambientes
- `local` → `staging` → `production`. Secrets via variáveis de ambiente / secret manager.
- Feature flags para escopo da gamificação e novas funcionalidades.
