# AGENTS.md — Guia do agente de código (Mentis)

> Lido pelo Codex (e compatíveis). O `CLAUDE.md` aponta para este mesmo núcleo.
> **Antes de escrever qualquer código, leia:** `PRD.md` → `SPEC.md` → `DESIGNSYSTEM.md` →
> `ARCHITECTURE.md` → `ROADMAP.md`. O protótipo `App TCC.dc.html` é a fonte da verdade visual.

---

## O que é o produto (em uma frase)
App mobile baseado em **TCC** que transforma exercícios, hábitos e registros em **tijolos** de
uma **cidade que cresce** — desenvolvimento pessoal prático, calmo e orientado por IA.

## Regras inegociáveis
1. **A IA é um guia estruturado, NUNCA um terapeuta.** Não diagnostica, não prescreve, não dá
   conselho clínico. Implemente os **guardrails de risco** do `SPEC §7` (acolhimento + recursos
   de emergência, ex. CVV 188) em todo fluxo de IA. Disclaimer "não substitui terapia" sempre presente.
2. **Toda ação vira tijolo.** Check-in, registro, exercício e hábito creditam a cidade segundo a
   tabela do `SPEC §3`. A gamificação é o diferencial — trate-a como núcleo, não enfeite.
3. **Nunca punir o usuário.** Sem remover progresso por inatividade, sem culpa, sem dark patterns.
4. **Tom calmo e acolhedor.** Siga `DESIGNSYSTEM.md` à risca: verde sage + clay, Newsreader +
   Plus Jakarta Sans, espaço generoso, baixa densidade, sem alarme visual.
5. **Privacidade de dados de saúde.** LGPD, criptografia, minimização ao enviar à IA. Conteúdo de
   diário nunca em logs em texto claro.

## Como trabalhar
- **TypeScript estrito.** Tipos compartilhados espelham `SPEC §2` (em `packages/shared`).
- **IA só pelo backend**, com schema de entrada/saída validado (zod) — a IA devolve **JSON
  estruturado**, não texto solto. Cliente nunca vê a chave da API.
- **Gamificação calculada no backend** (fonte da verdade dos tijolos); valores vêm de config/flags
  para tuning sem deploy. Atualização otimista no cliente é ok.
- **Offline-first** para check-ins, registros e hábitos; sincroniza depois.
- **Degradação graciosa:** se a IA falhar, a feature funciona sem a sugestão.
- Acessibilidade: alvos ≥44px, contraste AA, **cor nunca transmite estado sozinha** (sempre rótulo/ícone).

## Estilo de código
- Sem CSS global; use os tokens de `theme/tokens.ts` (derivados do `DESIGNSYSTEM.md`).
- Componentes pequenos e nomeados pelo papel (`MoodPicker`, `HabitRow`, `AIInsightCard`,
  `CityScene`, `BrickProgress`).
- A `CityScene` usa **apenas formas simples** (retângulos, triângulos via border, círculos) —
  nada de SVG complexo desenhado à mão.
- Validação na borda (entradas de usuário e respostas da IA) antes de persistir/exibir.

## Definition of Done
Use o checklist do `ROADMAP.md`. Resumo: segue design system; respeita contratos do `SPEC`;
IA dentro dos limites; acessível; offline onde especificado; testes nas regras de gamificação e
nos guardrails; typecheck + lint limpos.

## Fluxo sugerido por tarefa
1. Identifique a fase/feature no `ROADMAP.md` e os contratos no `SPEC.md`.
2. Implemente tipos compartilhados primeiro, depois backend (com validação + guardrails), depois UI.
3. Escreva testes das regras de gamificação e dos guardrails de risco.
4. Verifique contra o `DESIGNSYSTEM.md` e a tela equivalente no protótipo.
5. Rode typecheck, lint e testes antes de concluir.

## Comandos (preencher conforme o setup real)
```bash
# instalar
pnpm install
# mobile (Expo)
pnpm --filter mobile start
# backend
pnpm --filter api dev
# qualidade
pnpm typecheck && pnpm lint && pnpm test
```

## Não faça
- Não chame a IA direto do cliente. Não exponha chaves.
- Não introduza gradientes agressivos, emoji decorativo ou fontes fora do design system.
- Não trate crises com a IA — encaminhe a recursos profissionais.
- Não adicione conteúdo/seções não especificados sem pedir; menos é mais.
