# DESIGN SYSTEM — Mentis

**v1.0 — extraído do protótipo `App TCC.dc.html` (fonte da verdade visual).**
Tom: **calmo, acolhedor, terapêutico**. Verde sage como base, um clay morno para energia/sequência.
Sem gradientes agressivos, sem emoji decorativo, sem ansiedade visual.

---

## 1. Cores (tokens)

### Marca / primárias
| Token | Hex | Uso |
|---|---|---|
| `--color-forest` | `#34503f` | Primária forte: CTAs sólidos, aba ativa, títulos de destaque |
| `--color-sage` | `#6f9b84` | Primária suave: barras de progresso, ícones, aba Cidade |
| `--color-sage-tint` | `#dceadf` | Fundos de destaque suaves, blocos de IA |
| `--color-sage-surface` | `#e7efe7` | Superfície verde clara alternativa |

### Acento (clay / energia)
| Token | Hex | Uso |
|---|---|---|
| `--color-clay` | `#cf906c` | Sequência (streak), energia, intensidade emocional |
| `--color-clay-deep` | `#9c5a3a` | Texto sobre fundos clay |
| `--color-clay-soft` | `#f5e3d8` | Fundo de cartões de sequência / tags |

### Neutros
| Token | Hex | Uso |
|---|---|---|
| `--color-bg` | `#f0f3ed` | Fundo do app (off-white com leve verde) |
| `--color-surface` | `#ffffff` | Cartões |
| `--color-chip` | `#eef1ec` | Chips/segmentos neutros |
| `--color-border` | `#e3e9e1` | Bordas e divisórias |
| `--color-text` | `#283330` | Texto primário (quase-preto quente) |
| `--color-text-2` | `#69756e` | Texto secundário |
| `--color-text-3` | `#9aa49d` | Texto terciário / labels |
| `--color-device` | `#2b322c` | Moldura do dispositivo (mock) |
| `--color-stage` | `#d6ddd3` | Fundo atrás do dispositivo (mock) |

### Escala de humor (5 níveis)
Mesma cromaticidade, hue variando — nunca usar só a cor para o significado (sempre com rótulo).
| Nível | Label | Hex |
|---|---|---|
| 5 | Ótimo | `#6f9b84` |
| 4 | Bem | `#93b6a0` |
| 3 | Neutro | `#c9c191` |
| 2 | Baixo | `#d3a87f` |
| 1 | Difícil | `#c98a8a` |

> Regra de acento: todos os acentos compartilham chroma/lightness próximos; só o matiz muda.
> Saturação de brancos/pretos mantida baixa (tom quente, dessaturado).

## 2. Tipografia

Duas famílias (Google Fonts):

| Papel | Família | Pesos | Uso |
|---|---|---|---|
| **Display / serifa** | `Newsreader` | 400–600 | Saudações, títulos de tela, números grandes (humor editorial, calmo) |
| **UI / corpo** | `Plus Jakarta Sans` | 400–700 | Todo o restante: botões, labels, listas, corpo |

### Escala
| Token | px | Peso | Família |
|---|---:|---|---|
| Display L (saudação) | 30 | 500 | Newsreader |
| Título de tela | 28 | 500 | Newsreader |
| Número-estatística | 24–40 | 600 | Newsreader |
| Card title | 16 | 600 | Jakarta |
| Body | 14–15 | 400–500 | Jakarta |
| Label/eyebrow | 12–13 | 600, `letter-spacing .04em`, UPPERCASE | Jakarta |
| Nav label | 10.5 | 600 | Jakarta |
| Caption | 11–12 | 500 | Jakarta |

Line-height de corpo: ~1.5. Use `text-wrap: pretty` em parágrafos.

## 3. Espaçamento, raio e sombra

- **Grid base:** 4px. Padding de tela: `22px 18px`. Gap entre seções: `16–18px`.
- **Raio:** cartões `18–22px`; botões `12–14px`; pills/chips `999px`; círculos de humor `50%`.
- **Sombra padrão de cartão:** `0 6px 22px rgba(47,74,60,0.05)`.
- **Sombra de elemento elevado (aba Cidade):** `0 8px 20px rgba(52,80,63,0.30)`.

## 4. Componentes

### Botões
- **Primário sólido:** fundo `--color-forest`, texto branco, raio 12–14, peso 600.
- **Primário claro (sobre verde):** fundo branco, texto `--color-forest`.
- **Secundário/ghost:** fundo branco, texto `--color-text-3`, peso 600.

### Cartões
Superfície branca, raio 18–22, sombra padrão, padding 16–18. Cartão de destaque: fundo
`--color-forest` (texto claro) ou `--color-sage-tint` (bloco de IA).

### Bloco de IA ("Análise do guia")
Fundo `--color-sage-tint`, eyebrow `ANÁLISE DO GUIA` em `--color-forest`, ícone circular forest
com ponto interno. Texto em `--color-forest`/`#2f4a3c`. Destaques em `<strong>`.

### Check-in de humor
Linha de 5 itens: círculo externo (anel ativo na cor do humor) + disco colorido interno +
rótulo. Selecionado: borda 2px na cor + leve preenchimento (`cor + 22` alpha).

### Chips / tags
Pills 999px. Emoção ativa: fundo `--color-clay-soft`, texto `--color-clay-deep`. Neutra: fundo
`--color-chip`, texto `--color-text-2`. Tag "Recomendado": clay; tag "TCC": sage-tint.

### Checkbox de hábito / tarefa
Quadrado raio 7–9, 20–26px. Não feito: borda `#cdd6cd`. Feito: fundo `--color-sage`/forest +
✓ branco. Tarefa concluída: texto riscado em `--color-text-3`.

### Barras de progresso
Trilho `--color-chip`, preenchimento `--color-sage` (hábitos/metas) ou `--color-clay`
(intensidade emocional), raio 999. Anel (consistência): `conic-gradient(sage 0 X%, chip X% 100%)`
com disco branco central.

### Gráfico de barras (progresso emocional)
7 barras (dias), `max-width 22px`, raio 6. Dias bons (≥70%) em `--color-sage`; demais em
`#c2d6c8`. Rótulo do dia em `--color-text-3`.

### Bottom navigation
Barra branca, borda superior `--color-border`, 5 itens. Ícones line 1.9px stroke,
`currentColor`. Ativo: `--color-forest`; inativo: `--color-text-3`. Item central **Cidade**
elevado (`margin-top:-20px`), círculo 54px `--color-sage` (forest quando ativo) com sombra
elevada e ícone branco de prédios.

### Sequência (streak)
Cartão `--color-clay-soft`, ícone de "chama" (disco clay com forma `border-radius:50% 50% 50% 0`
rotacionada 45°), número grande em `--color-clay-deep`.

## 5. A Cidade (ilustração da gamificação)

Construída **apenas com formas CSS simples** (retângulos, triângulos via `border`, círculos) —
estilo flat, sem SVG complexo desenhado à mão.

- **Céu:** `linear-gradient(180deg,#e6f0ee,#eef2ea 55%,#f4eee2)`.
- **Sol:** círculo `#f0dca2` + halo `box-shadow 0 0 0 10px rgba(240,220,162,.25)`, animação `floatSun` suave.
- **Nuvens:** pills brancas translúcidas.
- **Chão:** faixa `#cfdec9` com linha `#c0d2ba`.
- **Edifício:** corpo retangular (cores: `#ffffff`, `#e7efe7`, `#efe7da`, `#f3ede3`),
  telhado = triângulo via `border-left/right transparent` + `border-bottom` na cor
  (`--color-sage` ou `--color-clay`); janelas = grade de quadradinhos 8px.
- **Árvore:** disco `--color-sage` + tronco `#9c8466`.
- **Em construção:** mesmo edifício com `opacity: .4`.
- **Lote bloqueado:** retângulo `border: 2px dashed rgba(52,80,63,.3)` com cadeado (ícone line).

Alturas/cores variam para dar ritmo; a cidade **cresce** com o progresso (mais edifícios,
edifício em construção evolui, lotes desbloqueiam).

## 6. Movimento
- Transições curtas e suaves (≤ 250ms). Nada brusco.
- `floatSun` (5s, ease-in-out, infinito) e `riseUp` (entrada de elementos) já definidos.
- Animações devem **sobreviver a re-render** — construir elementos animados em código quando preciso.

## 7. Princípios
1. **Acolhimento sobre performance visual** — espaço em branco generoso, baixa densidade.
2. **Sem alarme** — nunca vermelho de erro agressivo, nunca culpa por inatividade.
3. **Acento com parcimônia** — clay só para energia/sequência/intensidade; verde domina.
4. **Cor nunca sozinha** — todo estado tem rótulo/ícone além da cor (acessibilidade).
5. **Toque confortável** — alvos ≥ 44px.
