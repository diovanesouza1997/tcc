# Mentis — Assistente de Desenvolvimento Pessoal baseado em TCC

> SaaS/app mobile que transforma conceitos da Terapia Cognitivo-Comportamental em ações
> práticas, mensuráveis e **visíveis** — através de uma cidade que o usuário constrói ao evoluir.

Este repositório contém a **documentação primordial** para desenvolver o produto com
um agente de código (Claude Code / Codex) ou um time humano. Leia os documentos nesta ordem:

| Documento | O que contém | Para quem |
|---|---|---|
| [`PRD.md`](./PRD.md) | Visão, proposta de valor, público, métricas, escopo de MVP | Produto, todos |
| [`SPEC.md`](./SPEC.md) | Telas, fluxos, modelos de dados, regras da gamificação, contrato de IA | Eng + Produto |
| [`DESIGNSYSTEM.md`](./DESIGNSYSTEM.md) | Tokens (cor, tipo, espaçamento), componentes, padrões de UI | Design + Front-end |
| [`ARCHITECTURE.md`](./ARCHITECTURE.md) | Stack, estrutura de pastas, camadas, integrações | Engenharia |
| [`ROADMAP.md`](./ROADMAP.md) | Fases, MVP → v1, critérios de pronto | Produto + Eng |
| [`AGENTS.md`](./AGENTS.md) | Instruções para o Codex | Agente de código |
| [`CLAUDE.md`](./CLAUDE.md) | Instruções para o Claude Code | Agente de código |

## O protótipo
`App TCC.dc.html` é o protótipo navegável de referência (6 telas, Android). Trate-o como a
**fonte da verdade visual** — o `DESIGNSYSTEM.md` foi extraído dele.

## Princípios inegociáveis
1. **Ferramenta de desenvolvimento, não terapia.** A IA é um guia estruturado, nunca um terapeuta. Não diagnostica, não substitui acompanhamento clínico.
2. **Toda ação é tangível.** Cada exercício, hábito ou registro vira um tijolo na cidade do usuário.
3. **Calmo e acolhedor.** O produto lida com saúde mental — sem pressão, sem ansiedade visual, sem dark patterns.
4. **Pequeno e executável.** Objetivos abstratos sempre são quebrados em passos mínimos.
