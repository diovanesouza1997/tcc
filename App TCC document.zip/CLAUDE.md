# CLAUDE.md — Guia do Claude Code (Mentis)

Este projeto usa um **guia único de agente**. Siga **[`AGENTS.md`](./AGENTS.md)** — ele contém
todas as regras de trabalho, estilo e limites. Este arquivo existe para o Claude Code encontrar
o contexto automaticamente.

## Ordem de leitura obrigatória
1. [`PRD.md`](./PRD.md) — visão, valor, público, escopo
2. [`SPEC.md`](./SPEC.md) — telas, dados, regras de gamificação, contrato de IA
3. [`DESIGNSYSTEM.md`](./DESIGNSYSTEM.md) — tokens e componentes (fonte: protótipo `App TCC.dc.html`)
4. [`ARCHITECTURE.md`](./ARCHITECTURE.md) — stack e estrutura
5. [`ROADMAP.md`](./ROADMAP.md) — fases e Definition of Done
6. [`AGENTS.md`](./AGENTS.md) — **regras de execução do agente**

## Lembretes críticos (detalhe em AGENTS.md / SPEC §7)
- A **IA é guia, não terapeuta** — guardrails de risco + disclaimer obrigatórios.
- **Toda ação vira tijolo** na cidade (gamificação = núcleo do produto).
- **Nunca punir** o usuário; tom **calmo e acolhedor**; sem dark patterns.
- **IA só pelo backend**, com saída JSON validada; **LGPD** e dados de saúde protegidos.
- Siga `DESIGNSYSTEM.md`; acessibilidade AA; cor nunca sozinha.

## Definition of Done
Use o checklist do [`ROADMAP.md`](./ROADMAP.md).
