# SPEC — Mentis

**Especificação funcional e técnica · v1.0**
Acompanha `PRD.md` (o quê/por quê) e `DESIGNSYSTEM.md` (como deve parecer).

---

## 1. Navegação e telas

App mobile (Android-first, depois iOS). Navegação por **bottom nav de 5 abas**, com a aba
central **Cidade** elevada e destacada (é o diferencial).

```
[ Início ]  [ Diário ]  ( CIDADE )  [ Metas ]  [ Progresso ]
```

`Exercícios` é uma tela alcançada por cards do Início e pelo CTA "Reestruturar" do Diário
(não ocupa aba). Mapa completo de telas:

| Tela | Rota | Resumo |
|---|---|---|
| **Início** | `/` | Saudação, check-in de humor, foco do dia (IA), sequência, ações rápidas, prévia da cidade. |
| **Diário guiado** | `/diario` | Fluxo em etapas: situação → pensamento automático → emoção+intensidade → análise da IA. |
| **Exercícios** | `/exercicios` | Lista de exercícios de TCC adaptados; cada um abre um fluxo guiado. |
| **Metas** | `/metas` | Hábitos do dia (checklist) + objetivos quebrados em tarefas pequenas. |
| **Progresso** | `/progresso` | Evolução emocional, consistência, frequência de exercícios, tendências (IA). |
| **Cidade** | `/cidade` | Estado da cidade, estatísticas, próximo marco, áreas bloqueadas. |
| Onboarding | `/onboarding` | Captura objetivos, baseline de humor, primeiro tijolo. *(a especificar)* |

### 1.1 Início
- Data + saudação contextual ("Boa tarde, {nome}").
- **Check-in de humor:** 5 níveis (Ótimo · Bem · Neutro · Baixo · Difícil), 1 toque, grava `MoodEntry`.
- **Foco de hoje:** sugestão única gerada pela IA (ver §7) com CTA "Começar agora".
- **Cartão de sequência (streak)** em destaque clay.
- **Ações rápidas:** Novo registro, Exercícios, Metas, Progresso.
- **Prévia da Cidade:** skyline reduzido + total de tijolos + atalho.

### 1.2 Diário guiado inteligente
Fluxo estruturado (cada etapa é um cartão):
1. **Situação** — o que aconteceu (texto livre + prompt).
2. **Pensamento automático** — o que passou pela cabeça.
3. **Emoção + intensidade** — chips de emoção + slider 0–100%.
4. **Análise do guia (IA)** — identifica possível **distorção cognitiva**, explica em linguagem simples e oferece CTA "Reestruturar este pensamento" (→ Exercícios).
- Ação final: **Salvar registro** → grava `JournalEntry` e credita tijolos.

### 1.3 Exercícios
- Lista de exercícios de TCC, cada card: tag, duração estimada, título, descrição.
- Catálogo inicial (`ExerciseType`): `thought_record`, `core_beliefs`, `cognitive_restructuring`, `behavioral_hypothesis`, `action_planning`.
- Exercícios são **adaptados ao histórico** (IA prioriza e personaliza prompts).
- Concluir um exercício grava `ExerciseSession` e credita tijolos.

### 1.4 Metas e planejamento
- **Hábitos de hoje:** checklist; marcar/desmarcar alterna `done` e atualiza streak + tijolos.
- **Objetivos:** cartão com barra de progresso e **subtarefas pequenas** (3/5 concluídas).
- A IA ajuda a **quebrar objetivos abstratos** em tarefas mínimas executáveis.
- Ação: "+ Nova meta".

### 1.5 Progresso
- Seletor de período (Semana / Mês).
- **Evolução emocional:** gráfico de barras por dia (cor reforça dias bons).
- **Consistência de hábitos:** anel percentual.
- **Exercícios concluídos:** número + mini-barras.
- **Tendências detectadas (IA):** cartões de insight em linguagem natural.

### 1.6 Cidade (gamificação)
- Cabeçalho: nome da vila + nível.
- **Estatísticas:** tijolos, edifícios, dias seguidos.
- **Cena da cidade:** edifícios construídos (alturas/cores variadas), árvores, um edifício
  em construção (opacidade reduzida) e um **lote bloqueado** (desbloqueável).
- **Próximo marco:** "Próximo edifício: {nome} — {progresso}%" + o que falta para concluir.

## 2. Modelos de dados

> Tipos em TypeScript como referência de contrato (independente do banco escolhido).

```ts
type ID = string;

interface User {
  id: ID;
  name: string;
  createdAt: string;
  goals: string[];               // objetivos declarados no onboarding
  baselineMood?: MoodLevel;
  timezone: string;
  reminderPrefs: ReminderPrefs;
}

type MoodLevel = 1 | 2 | 3 | 4 | 5; // 1 Difícil … 5 Ótimo
interface MoodEntry { id: ID; userId: ID; level: MoodLevel; note?: string; createdAt: string; }

interface JournalEntry {
  id: ID; userId: ID;
  situation: string;
  automaticThought: string;
  emotions: { label: string; intensity: number }[]; // intensity 0–100
  detectedDistortion?: CognitiveDistortion;          // preenchido pela IA
  reframe?: string;                                  // resultado da reestruturação
  createdAt: string;
}

type CognitiveDistortion =
  | 'catastrofizacao' | 'leitura_mental' | 'adivinhacao' | 'pensamento_tudo_ou_nada'
  | 'generalizacao' | 'filtro_negativo' | 'desqualificar_positivo' | 'personalizacao'
  | 'deveria' | 'rotulacao' | 'raciocinio_emocional';

type ExerciseType =
  | 'thought_record' | 'core_beliefs' | 'cognitive_restructuring'
  | 'behavioral_hypothesis' | 'action_planning';
interface Exercise { id: ID; type: ExerciseType; title: string; description: string; estMinutes: number; }
interface ExerciseSession { id: ID; userId: ID; exerciseId: ID; completedAt: string; payload: Record<string, unknown>; bricksAwarded: number; }

interface Habit { id: ID; userId: ID; name: string; schedule?: string; streak: number; }
interface HabitLog { id: ID; habitId: ID; date: string; done: boolean; }

interface Goal { id: ID; userId: ID; title: string; tasks: Task[]; createdAt: string; }
interface Task { id: ID; title: string; done: boolean; }

interface ReminderPrefs { enabled: boolean; quietHours?: [string, string]; channels: ('push')[]; }

// Gamificação
interface CityState {
  userId: ID;
  bricks: number;
  level: number;
  villageName: string;
  buildings: Building[];
  unlockedAreas: string[];
}
interface Building { id: ID; type: BuildingType; progress: number; builtAt?: string; } // progress 0–100
type BuildingType = 'casa' | 'edificio' | 'biblioteca' | 'parque' | 'praca' | 'mercado';
```

## 3. Regras da gamificação (a Cidade)

Fonte única de verdade para créditos. Valores são **configuráveis** (feature flags / config remota).

| Ação | Tijolos | Observação |
|---|---:|---|
| Check-in de humor | +5 | máx. 1/dia creditado |
| Registro no diário (completo) | +20 | exige as 4 etapas |
| Exercício de TCC concluído | +25 a +40 | varia por `estMinutes` |
| Hábito marcado como feito | +15 | reverte −15 ao desmarcar no mesmo dia |
| Manter sequência diária | bônus +10 | a cada dia consecutivo com ≥1 ação |

**Construção:** tijolos acumulam em direção ao **próximo edifício** (cada edifício tem um custo
em tijolos). Ao atingir 100%, o edifício é "construído" e some o estado de construção.
**Áreas/Nível:** sequências longas e nº de edifícios desbloqueiam novas áreas e elevam o nível
da vila (ex.: "Vila Florescente · Nível 4"). Definir tabela de thresholds em config.

Regras de tom: nunca punir (não remover tijolos por inatividade); ausência de pressão; a
narrativa é de crescimento gentil, não de competição.

## 4. Lembretes inteligentes (F4)
- Baseados em horário, rotina, comportamento anterior e padrões detectados.
- Respeitar `quietHours`; nunca enviar mensagens culpabilizadoras.
- Frequência adaptativa: reduzir se o usuário ignora; reforçar janelas de maior aderência.

## 5. Análise de progresso (F5)
- Agregações por dia/semana/mês a partir de `MoodEntry`, `HabitLog`, `ExerciseSession`.
- Tendências geradas pela IA em linguagem natural, sempre **descritivas e acionáveis**
  ("sua ansiedade tende a subir nas noites de domingo — um exercício de planejamento pode ajudar").

## 6. Estados, vazios e erros
- **Primeiro uso:** onboarding define objetivos + baseline; cidade começa com **1 edifício**.
- **Estados vazios:** mensagens acolhedoras, nunca culpa ("Comece quando quiser").
- **Offline:** registros e check-ins funcionam offline e sincronizam depois.
- **Falha de IA:** degradar com elegância — exercícios e registros funcionam sem sugestão da IA.

## 7. Contrato da IA (limites e comportamento)

A IA é um **guia estruturado de TCC**, não um terapeuta. Regras:

1. **Não** diagnostica, **não** prescreve, **não** dá conselho médico.
2. Linguagem simples, validante e sem jargão; explica o "porquê" do exercício.
3. Identifica distorções cognitivas a partir de `JournalEntry` e nomeia em linguagem leiga.
4. Personaliza exercícios e metas com base no histórico do usuário.
5. **Segurança:** ao detectar sinais de risco (ideação suicida, autoagressão, crise), exibe
   acolhimento + **recursos de emergência** (ex.: CVV 188 no Brasil) e recomenda ajuda
   profissional. Nunca tenta "tratar" a crise.
6. Disclaimer persistente: ferramenta de desenvolvimento pessoal, **não substitui terapia**.

**Saídas estruturadas:** a IA deve retornar JSON validável (ex.: `{ distortion, explanation,
reframePrompt }`) para alimentar a UI sem texto solto. Definir schema por endpoint em `ARCHITECTURE.md`.

## 8. Privacidade e conformidade
- Dados sensíveis (saúde mental): criptografia em repouso e em trânsito.
- Conformidade com **LGPD**; consentimento explícito; exportação e exclusão de dados pelo usuário.
- Minimização: enviar à IA apenas o necessário; permitir modo de retenção reduzida.

## 9. Acessibilidade
- Alvos de toque ≥ 44px; contraste AA; suporte a fontes ampliadas; rótulos para leitores de tela.
- Sem depender só de cor para transmitir estado (humor, progresso).
